/*
 * Decompiled with CFR 0_118.
 */
package Exceptions;

import Exceptions.ModbusException;

public class StartingAddressInvalidException
extends ModbusException {
    public StartingAddressInvalidException() {
    }

    public StartingAddressInvalidException(String s) {
        super(s);
    }
}

