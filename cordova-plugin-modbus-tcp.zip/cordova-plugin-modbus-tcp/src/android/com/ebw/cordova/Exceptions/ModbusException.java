/*
 * Decompiled with CFR 0_118.
 */
package Exceptions;

public class ModbusException
extends Exception {
    public ModbusException() {
    }

    public ModbusException(String s) {
        super(s);
    }
}

