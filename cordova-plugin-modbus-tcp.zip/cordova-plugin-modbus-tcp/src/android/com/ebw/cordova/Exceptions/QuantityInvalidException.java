/*
 * Decompiled with CFR 0_118.
 */
package Exceptions;

import Exceptions.ModbusException;

public class QuantityInvalidException
extends ModbusException {
    public QuantityInvalidException() {
    }

    public QuantityInvalidException(String s) {
        super(s);
    }
}

