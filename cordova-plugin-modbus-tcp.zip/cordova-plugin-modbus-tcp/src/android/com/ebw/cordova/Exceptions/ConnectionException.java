/*
 * Decompiled with CFR 0_118.
 */
package Exceptions;

import Exceptions.ModbusException;

public class ConnectionException
extends ModbusException {
    public ConnectionException() {
    }

    public ConnectionException(String s) {
        super(s);
    }
}

