/*
 * Decompiled with CFR 0_118.
 */
package ModbusClient;

public interface ReceiveDataChangedListener {
    public void ReceiveDataChanged();
}

