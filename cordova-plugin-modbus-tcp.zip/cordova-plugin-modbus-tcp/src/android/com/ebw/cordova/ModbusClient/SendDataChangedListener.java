/*
 * Decompiled with CFR 0_118.
 */
package ModbusClient;

public interface SendDataChangedListener {
    public void SendDataChanged();
}

