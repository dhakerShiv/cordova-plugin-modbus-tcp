/*
 * Decompiled with CFR 0_118.
 */
package ModbusClientExample;

import ModbusClientExample.EasyModbusTCPClientExampleGUI;

public class EasyModbusTCPClientExampleJava {
    public static void main(String[] args) {
        EasyModbusTCPClientExampleGUI _easyModbusTCPClientExampleGUI = new EasyModbusTCPClientExampleGUI();
        _easyModbusTCPClientExampleGUI.setVisible(true);
    }
}

